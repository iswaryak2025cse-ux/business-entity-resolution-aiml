from pathlib import Path
import pandas as pd

def f05(pred, truth):
    p = set(x for x in pred.split(",") if x)
    t = set(x for x in truth.split(",") if x)
    if not p and not t: return 1.0
    if not p: return 0.0
    tp = len(p & t)
    precision = tp / len(p)
    recall = tp / len(t) if t else 0.0
    return (1.25 * precision * recall) / (0.25 * precision + recall) if (precision + recall) else 0.0

base = Path(".")
pred = pd.read_csv(base/"output/matching_results.tsv", sep="\t", dtype=str, keep_default_na=False)
truth = pd.read_csv(base/"dataset/train/train_ground_truth.tsv", sep="\t", dtype=str, keep_default_na=False)

# Demo evaluation is intended only when test IDs have been aligned with a validation set.
print("Official challenge metric: macro F_0.5, with precision weighted more heavily than recall.")
print("Use a held-out validation split from training data for a true score.")
