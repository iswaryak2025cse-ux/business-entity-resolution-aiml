import argparse, re, unicodedata
from pathlib import Path
import pandas as pd
from difflib import SequenceMatcher

LEGAL = {
    "private": "pvt", "limited": "ltd", "corporation": "corp",
    "incorporated": "inc", "company": "co"
}
ABBR = {
    "road": "rd", "street": "st", "avenue": "ave", "boulevard": "blvd",
    "main": "main", "private": "pvt", "limited": "ltd"
}

def normalize(text):
    text = "" if pd.isna(text) else str(text)
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    text = text.lower()
    for a, b in LEGAL.items():
        text = re.sub(r"\b" + re.escape(a) + r"\b", b, text)
    for a, b in ABBR.items():
        text = re.sub(r"\b" + re.escape(a) + r"\b", b, text)
    text = re.sub(r"[^a-z0-9 ]+", " ", text)
    return " ".join(text.split())

def similarity(a, b):
    return SequenceMatcher(None, normalize(a), normalize(b)).ratio()

def score_pair(a, b):
    name = similarity(a.business_name, b.business_name)
    addr = similarity(a.business_address, b.business_address)
    country = 1.0 if normalize(a.country) == normalize(b.country) else 0.0
    # Precision-oriented score: name is most important, then address.
    return 0.50 * name + 0.45 * addr + 0.05 * country

def load(path):
    return pd.read_csv(path, sep="\t", dtype=str, keep_default_na=False)

def main(data_dir, threshold):
    data_dir = Path(data_dir)
    test = data_dir / "dataset" / "test"
    out = data_dir / "output"
    out.mkdir(exist_ok=True)

    s1 = load(test/"test_source1.tsv")
    s2 = load(test/"test_source2.tsv")
    s3 = load(test/"test_source3.tsv")
    candidates = pd.concat([s2, s3], ignore_index=True)

    match_rows, candidate_rows = [], []

    for _, row in s1.iterrows():
        scored = []
        for _, cand in candidates.iterrows():
            # Simple blocking: same country and at least some name/address overlap.
            if normalize(row.country) != normalize(cand.country):
                continue
            n1, n2 = normalize(row.business_name), normalize(cand.business_name)
            a1, a2 = normalize(row.business_address), normalize(cand.business_address)
            if not (n1[:4] == n2[:4] or a1[:6] == a2[:6] or
                    similarity(row.business_name, cand.business_name) >= 0.45 or
                    similarity(row.business_address, cand.business_address) >= 0.55):
                continue
            sc = score_pair(row, cand)
            scored.append((cand.entity_id, sc))

        scored.sort(key=lambda x: x[1], reverse=True)
        cand_ids = [x[0] for x in scored]
        match_ids = [x[0] for x in scored if x[1] >= threshold]

        candidate_rows.append({
            "source1_entity_id": row.entity_id,
            "candidate_entity_ids": ",".join(cand_ids)
        })
        match_rows.append({
            "source1_entity_id": row.entity_id,
            "matched_entity_ids": ",".join(match_ids)
        })

    pd.DataFrame(match_rows).to_csv(out/"matching_results.tsv", sep="\t", index=False)
    pd.DataFrame(candidate_rows).to_csv(out/"candidate_pairs.tsv", sep="\t", index=False)
    print("Created:", out/"matching_results.tsv")
    print("Created:", out/"candidate_pairs.tsv")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", default=".")
    p.add_argument("--threshold", type=float, default=0.72)
    args = p.parse_args()
    main(args.data_dir, args.threshold)
