# Methodology

## Problem
Entity resolution identifies records that represent the same real-world business across independent sources.

## Preprocessing
- Unicode normalization
- Lowercasing
- Punctuation removal
- Common legal suffix normalization
- Common address abbreviation normalization

## Candidate Generation
Candidates are generated using country agreement plus partial name/address keys and similarity checks.

## Features
- Business-name similarity
- Business-address similarity
- Country agreement

## Matching
A weighted score is calculated and compared with a configurable threshold. The threshold is intentionally conservative because the challenge uses the precision-heavy macro F_0.5 metric.

## Outputs
`matching_results.tsv` contains final matches.
`candidate_pairs.tsv` contains candidates considered before final matching.
