# AIML Project - Business Entity Resolution

## Objective
Match noisy business records from Source 2 and Source 3 to the corresponding Source 1 business using machine learning / similarity-based entity resolution.

The challenge specification requires TSV input/output, candidate generation (blocking), matching, and `matching_results.tsv` plus `candidate_pairs.tsv`.

## Project structure
```text
business_entity_resolution/
├── dataset/
│   ├── train/
│   └── test/
├── output/
├── src/
│   ├── entity_resolution.py
│   └── evaluate.py
├── docs/
├── requirements.txt
└── README.md
```

## VS Code steps

### 1. Open the folder
Open this folder in VS Code.

### 2. Create virtual environment
Windows:
```powershell
py -m venv .venv
.\.venv\Scripts\activate
```

### 3. Install packages
```powershell
python -m pip install -r requirements.txt
```

### 4. Run
```powershell
python src/entity_resolution.py --data-dir . --threshold 0.72
```

The program creates:
- `output/matching_results.tsv`
- `output/candidate_pairs.tsv`

## How the model works
1. Load Source 1, Source 2 and Source 3.
2. Normalize business names and addresses.
3. Generate candidate pairs using blocking.
4. Calculate name similarity, address similarity and country agreement.
5. Combine the features into a matching score.
6. Apply a threshold to make the final match decision.
7. Save the candidate set and final matches.

## Important for the real challenge dataset
Replace the demo TSV files with the official challenge/Kaggle data while preserving these filenames:
- train_source1.tsv
- train_source2.tsv
- train_source3.tsv
- train_ground_truth.tsv
- test_source1.tsv
- test_source2.tsv
- test_source3.tsv

Do NOT put a multi-million-row dataset into GitHub. Keep large raw data locally or use the dataset platform's download mechanism. The challenge specification also prohibits external business lookups/enrichment.

## GitHub
```powershell
git init
git add .
git commit -m "Initial AIML entity resolution project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```
